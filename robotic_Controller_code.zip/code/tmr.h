#ifndef _TMR_H
#define _TMR_H
/*******************************************************************************
* Filename    :- tmr.h
* Module      :- TMR
*-------------------------------------------------------------------------------  
* Description :- Contains global functions and variables of timer
*-------------------------------------------------------------------------------  
* Environment :- ARM STM32F205VE, no OS, compiled with KEIL RealView
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2013 MAPS Technologies, Jaipur         
* Author      :- Mahabir Prasad
*******************************************************************************/ 
/******************************************************************************/
/* Path where it is stored for configuration management                       */
/* $Log:  $                                                                   */
/******************************************************************************/

/******************************************************************************/
/* Includes																																		*/
/******************************************************************************/
#include  "global.h"

/******************************************************************************/
/* Defines				                                                            */
/******************************************************************************/
#ifdef _TMR_C
  #define TMR_EXTERN    
#else
  #define TMR_EXTERN    extern
#endif

/*******************************************************************************
* CONFIGURATION OF MAIN-LOOP TIMERS
*******************************************************************************/
// Below add in order Mainloop function timer name and its call back function 
#define	KEY_MGR_ML_TMR				0
	
#define TMR_NUM_MODULE_MAINL  1  /* No. of module timers on mainloop level.   */
                                 /* timer defines above.(max. 256)            */
#if (TMR_NUM_MODULE_MAINL > 0)
   #define TMR_USE_MODULE_MAINL
#endif
/*******************************************************************************
* CONFIGURATION OF ISR TIMERS
*******************************************************************************/
// Below add in order ISR function timer name and its call back function in 
// tmr_tab.h at same place, i.e. order and number should be same. 
#define DSP_REF_ISR_TMR				(0u)

#define TMR_MOTOR_1_ISR       (0u)
#define TMR_MOTOR_2_ISR       (1u)
#define TMR_MOTOR_3_ISR       (2u)
#define TMR_MOTOR_4_ISR       (3u)
#define TMR_MOTOR_5_ISR       (4u)
#define TMR_MOTOR_6_ISR       (5u)
#define TMR_MOTOR_7_ISR       (6u)

#define TMR_NUM_MODULE_ISR     7 /* No. of module timers on interrupt level.  */
                                 /* timer defines above. (max. 256)           */
#if (TMR_NUM_MODULE_ISR > 0)
   #define TMR_USE_MODULE_ISR
#endif
/******************************************************************************/
/* the timer resolution is used in the macros for calculation of the timer    */
/* value out of the amount of milliseconds or microseconds                    */
#define TMR_RESOLUTION (1000UL)
/* macro for the module mainloop timer to set                              */
/* delay is calculated in ms independent from the sysclk.                  */
#define TMR_ML_MSEC(x) (((x) == 0) ? 0 : (((x) > 65535) ? 65535 : (x)))
#ifdef TMR_USE_MODULE_ISR 
  /* macro for the module interrupt timer to set                           */
  /* delays in ms independent from the sysclk.                             */
  #define TMR_ISR_MSEC(x) (((x) == 0) ? 0 : (((x) > 255) ? 255 : (x)))
#endif /* TMR_USE_MODULE_ISR  */

/******************************************************************************/
/* Globale Variables                                                          */
/******************************************************************************/

/******************************************************************************/
/* Global Prototypes					                                                */
/******************************************************************************/
TMR_EXTERN  void TMR_vStart(void);

#ifdef TMR_USE_MODULE_ISR 
  TMR_EXTERN  void TMR_vStartModuleIsrTmr(ubyte ubTmrNum, uword ubCount);
  #define TMR_vStopModuleIsrTmr(x)  TMR_vStartModuleIsrTmr((x),0)
#endif

#ifdef TMR_USE_MODULE_MAINL
  TMR_EXTERN  void TMR_vStartModuleMainlTmr(ubyte ubTmrNum, uword uwCount);
  #define TMR_vStopModuleMainlTmr(x)  TMR_vStartModuleMainlTmr((x),0)
#endif

TMR_EXTERN  void TMR_vServiceISR(void);
TMR_EXTERN  void TMR_vHandleStages(void);

void InitSystemTimer( void );

/******************************************************************************/
#endif                                                              /* _TMR_H */
/******************************************************************************/
/* Changes in version                                                         */
/* $History:  $                                                               */
/******************************************************************************/
/* End of Header File                                                         */
/******************************************************************************/
