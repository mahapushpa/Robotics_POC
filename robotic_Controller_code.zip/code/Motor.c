
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>

#include "tmr.h"
#include "Motor.h"
/* ------------------------------------------------------------------------- */
                                //GPIO No---header Pin num 
#define cMotor_1_PlusePin         (13u)     //21
#define cMotor_1_DirectionPin     (6u)      //22
#define cMotor_2_PlusePin         (26u)     //32
#define cMotor_2_DirectionPin     (31u)     //28
#define cMotor_3_PlusePin         (16u)     //10
#define cMotor_3_DirectionPin     (12u)     //19
#define cMotor_4_PlusePin         (21u)     //29
#define cMotor_4_DirectionPin     (30u)     //27
#define cMotor_5_PlusePin         (24u)     //35
#define cMotor_5_DirectionPin     (23u)     //33
#define cMotor_6_PlusePin         (22u)     //31
#define cMotor_6_DirectionPin     (27u)     //36
#define cMotor_7_PlusePin         (3u)      //15
#define cMotor_7_DirectionPin     (4u)      //16
 
/* ------------------------------------------------------------------------- */ 

enum 
{
  eLOW = 0u,
  eHIGH
};

/* ------------------------------------------------------------------------- */ 
static void sig_handler ( int signo );
static void timer_seconds ( long int seconds );
static void timer_useconds ( long int useconds );

/* ------------------------------------------------------------------------- */ 
const ubyte MotorPlusePin[ ] = 
  { cMotor_1_PlusePin, cMotor_2_PlusePin, 
    cMotor_3_PlusePin, cMotor_4_PlusePin, cMotor_5_PlusePin,
    cMotor_6_PlusePin, cMotor_7_PlusePin 
  };
        
const ubyte MotordirectionPin[ ] = 
  { cMotor_1_DirectionPin, cMotor_2_DirectionPin, 
    cMotor_3_DirectionPin, cMotor_4_DirectionPin, cMotor_5_DirectionPin, 
    cMotor_6_DirectionPin, cMotor_7_DirectionPin 
  };
 
/* ------------------------------------------------------------------------- */ 
stMotordrive Motordrive[ cMaxMotors ];
/* ------------------------------------------------------------------------- */ 
ubyte InitMotorParams( void )
{
  ubyte  Idx;
  
  if(wiringPiSetup() == -1)
  { //when initialize wiringPi failed, print message to screen
    printf("setup wiringPi failed !\n");
    return -1;
  }
  return 1u;
}
/* ------------------------------------------------------------------------- */ 
void InitSystemTimer( void )
{
  signal ( SIGALRM, sig_handler );
  timer_useconds( 1000 );
}
/* ------------------------------------------------------------------------- */ 
static void timer_seconds ( long int seconds )
{
  struct itimerval timer1;
 
  timer1 . it_interval . tv_usec = 0;
  timer1 . it_interval . tv_sec = seconds;
  timer1 . it_value . tv_usec = 0;
  timer1 . it_value . tv_sec = seconds;
 
  setitimer ( ITIMER_REAL, &timer1, NULL );
}
/* ------------------------------------------------------------------------- */ 
static void timer_useconds ( long int useconds )
{
  struct itimerval timer2;
 
  timer2.it_interval.tv_usec = useconds;
  timer2.it_interval.tv_sec = 0;
  timer2.it_value.tv_usec = useconds;
  timer2.it_value.tv_sec = 0;
 
  setitimer ( ITIMER_REAL, &timer2, NULL );
}
/* ------------------------------------------------------------------------- */
static void sig_handler( int signo )
{
  TMR_vServiceISR();  
}
/* ------------------------------------------------------------------------- */
const ubyte MotorTimerIdx[ ] = 
  { TMR_MOTOR_1_ISR, TMR_MOTOR_2_ISR, TMR_MOTOR_3_ISR, TMR_MOTOR_4_ISR,
    TMR_MOTOR_5_ISR, TMR_MOTOR_6_ISR, TMR_MOTOR_7_ISR 
  };
  
void InitMotorGPIO_g( 
  ubyte MotorNum_p, 
  ubyte State_p, 
  stMotordrive Motordriver_p )
{
  if( State_p == INPUT )
  {
    TMR_vStopModuleIsrTmr(MotorTimerIdx[ MotorNum_p ] );
    
    pinMode( MotorPlusePin[ MotorNum_p ], INPUT );
    pinMode( MotordirectionPin[ MotorNum_p ], INPUT );
  }
  else
  {
    pinMode( MotorPlusePin[ MotorNum_p ], OUTPUT );
    pinMode( MotordirectionPin[ MotorNum_p ], OUTPUT );
    
    digitalWrite( MotorPlusePin[ MotorNum_p ], eLOW );
    
    Motordrive[ MotorNum_p ].Direction = Motordriver_p.Direction;
  
    if( Motordrive[ MotorNum_p ].Direction == eReverse )  
    {
      digitalWrite( MotordirectionPin[ MotorNum_p ], eLOW );  
    }
    else
    {
      digitalWrite( MotordirectionPin[ MotorNum_p ], eHIGH );
    }
    
    Motordrive[ eMotor_1 ].PlusState = eLOW; 
    Motordrive[ MotorNum_p ].SpeedOnTime = Motordriver_p.SpeedOnTime;
    Motordrive[ MotorNum_p ].SpeedOffTime = Motordriver_p.SpeedOffTime;
    
    TMR_vStartModuleIsrTmr( MotorTimerIdx[ MotorNum_p ], Motordrive[ MotorNum_p ].SpeedOnTime );
  }
} 
/* ------------------------------------------------------------------------- */ 
void Motor_1_Timer( void )
{
  if( Motordrive[ eMotor_1 ].PlusState == eLOW )
  {
    digitalWrite(MotorPlusePin[ eMotor_1 ], eHIGH);
    Motordrive[ eMotor_1 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_1_ISR, Motordrive[ eMotor_1 ].SpeedOnTime );
  }
  else
  {
    digitalWrite(MotorPlusePin[ eMotor_1 ], eLOW);
    Motordrive[ eMotor_1 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_1_ISR, Motordrive[ eMotor_1 ].SpeedOffTime );
  }
//  printf( " Motor -1\n");
}
/* ----------------------------------------------------------------- */
void Motor_2_Timer( void )
{
  if( Motordrive[ eMotor_2 ].PlusState == eLOW )
  {
    digitalWrite(MotorPlusePin[ eMotor_2 ], eHIGH);
    Motordrive[ eMotor_2 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_2_ISR, Motordrive[ eMotor_2 ].SpeedOnTime );
  }
  else
  {
    digitalWrite(MotorPlusePin[ eMotor_2 ], eLOW);
    Motordrive[ eMotor_2 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_2_ISR, Motordrive[ eMotor_2 ].SpeedOffTime );
  }
//  printf( " Motor -2\n");
}
/* ----------------------------------------------------------------- */
void Motor_3_Timer( void )
{
  if( Motordrive[ eMotor_3 ].PlusState == eLOW )
  {
    digitalWrite(MotorPlusePin[ eMotor_3 ], eHIGH);
    Motordrive[ eMotor_3 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_3_ISR, Motordrive[ eMotor_3 ].SpeedOnTime );
  }
  else
  {
    digitalWrite(MotorPlusePin[ eMotor_3 ], eLOW);
    Motordrive[ eMotor_3 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_3_ISR, Motordrive[ eMotor_3 ].SpeedOffTime );
  }  
 // printf( " Motor -3\n");
}
/* ----------------------------------------------------------------- */
void Motor_4_Timer( void )
{
  if( Motordrive[ eMotor_4 ].PlusState == eLOW )
  {
    digitalWrite(MotorPlusePin[ eMotor_4 ], eHIGH);
    Motordrive[ eMotor_4 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_4_ISR, Motordrive[ eMotor_4 ].SpeedOnTime );
  }
  else
  {
    digitalWrite( MotorPlusePin[ eMotor_4 ], eLOW );
    Motordrive[ eMotor_4 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_4_ISR, Motordrive[ eMotor_4 ].SpeedOffTime );
  }
    
 // printf( " Motor -4\n");
}
/* ----------------------------------------------------------------- */
void Motor_5_Timer( void )
{
  if( Motordrive[ eMotor_5 ].PlusState == eLOW )
  {
    digitalWrite(MotorPlusePin[ eMotor_5 ], eHIGH);
    Motordrive[ eMotor_5 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_5_ISR, Motordrive[ eMotor_5 ].SpeedOnTime );   
  }
  else
  {
    digitalWrite( MotorPlusePin[ eMotor_5 ], eLOW );
    Motordrive[ eMotor_5 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_5_ISR, Motordrive[ eMotor_5 ].SpeedOffTime );
  }  
 // printf( " Motor -5\n");
}
/* ----------------------------------------------------------------- */
void Motor_6_Timer( void )
{
  if( Motordrive[ eMotor_6 ].PlusState == eLOW )
  {
    digitalWrite( MotorPlusePin[ eMotor_6 ], eHIGH );
    Motordrive[ eMotor_6 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_6_ISR, Motordrive[ eMotor_6 ].SpeedOnTime );   
  }
  else
  {
    digitalWrite(MotorPlusePin[ eMotor_6 ], eLOW);
    Motordrive[ eMotor_6 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_6_ISR, Motordrive[ eMotor_6 ].SpeedOffTime );
  }  
 // printf( " Motor -6\n");
}
/* ----------------------------------------------------------------- */
void Motor_7_Timer( void )
{
  if( Motordrive[ eMotor_7 ].PlusState == eLOW )
  {
    digitalWrite(MotorPlusePin[ eMotor_7 ], eHIGH);
    Motordrive[ eMotor_7 ].PlusState = eHIGH;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_7_ISR, Motordrive[ eMotor_7 ].SpeedOnTime );   
  }
  else
  {
    digitalWrite( MotorPlusePin[ eMotor_7 ], eLOW );
    Motordrive[ eMotor_7 ].PlusState = eLOW;
    TMR_vStartModuleIsrTmr( TMR_MOTOR_7_ISR, Motordrive[ eMotor_7 ].SpeedOffTime );
  }  
 // printf( " Motor -7\n");
}
/* ----------------------------------------------------------------- */
