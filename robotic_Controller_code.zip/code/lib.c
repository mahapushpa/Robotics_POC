/*******************************************************************************
* Filename    :- lib.c
* Module      :- function library
*------------------------------------------------------------------------------
* Description :- This module contains all functions usefull for more
*                than one member.
*-------------------------------------------------------------------------------  
* Environment :- ARM STM32F205VE, no OS, compiled with KEIL RealView
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2013 MAPS Technologies, Jaipur         
 Author      :- Mahabir Prasad
*******************************************************************************/ 
/******************************************************************************/
/* Path where it is stored for configuration management                       */
/* $Log:  $                                                                   */
/******************************************************************************/

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include  "global.h"
#include  "lib.h"

/******************************************************************************/
/* Defines                                                                    */
/******************************************************************************/
  /* none */

/******************************************************************************/
/* Internal Structures / Unions                                               */
/******************************************************************************/
  /* none */

/******************************************************************************/
/* Local Variables                                                            */
/******************************************************************************/
  /* none */

/******************************************************************************/
/* Internal Function prottypes                                                */
/******************************************************************************/
  /* none */

/******************************************************************************/
/* Internal Functions                                                         */
/******************************************************************************/
  /* none */

/******************************************************************************/
/* Global Functions                                                           */
/******************************************************************************/
/******************************************************************************* 
* Function   :- LIB_ubBcd2Dec() / LIB_uwBcd2Dec()
*-------------------------------------------------------------------------------  
* Description:- Converts a BCD number into decimal number.
*-------------------------------------------------------------------------------  
* Globals    :-
*-------------------------------------------------------------------------------  
* Parameter  :- Hex value
*-------------------------------------------------------------------------------  
* ReturnValue:- BCD value
*******************************************************************************/
#if 1                                   /* we want to have one function only; */
                                        /* the second is generated as a macro */
ubyte LIB_ubBcd2Dec(ubyte ubHex)
{
  ubyte ubDec = (ubHex >> 4);                           /* extract second BCD */
                                                        /* digit              */
  ubDec *= 10;                                          /* calculate and add  */
  ubDec += (ubHex & 0x0F);                              /* both decim. digits */

  return(ubDec);

} /* LIB_ubBcd2Dec() */

#else
uword LIB_uwBcd2Dec(uword uwHex)
{
  smctr smIndex;                                        /* loop counter       */
  uword uwDec = 0,                                      /* converted number   */
        uwMul = 1;                                      /* pos multiplicator  */

  for( smIndex = 3; smIndex >= 0; smIndex--)            /* loop for 4 digits  */
  {
    uwDec +=  ((uwHex & 0x000F) * uwMul);               /* convert curr digit */
    uwHex >>= 4;                                        /* next BCD digit     */
    uwMul *=  10;                                       /* next decimal digit */
  }
  return(uwDec);
} /* LIB_uwBcd2Dec() */

#endif

ubyte LIB_ubDec2Bcd(ubyte ubDec) // hex value to BCD conversion
{
  ubyte ubBcd;

  if(ubDec > 99)    // only 00..99 are used
  {
    //PWR_vAssert(__FILE__, __LINE__);     /* only digits can be converted      */
  }
  
  ubBcd = (ubDec/10);                             /* extract 10's         */
  ubBcd <<= 4;                                    /* shift to upper nible */
  ubBcd  |= ubDec%10;                             /* extract 1's          */
  return(ubBcd);

} /* LIB_ubBcd2Dec() */

uword LIB_uwDec2Bcd(ubyte ubDec) // hex value to BCD conversion
{
  uword uwBcd;
  
  uwBcd = (ubDec/100);                            /* extract 100's        */
  uwBcd <<= 4;                                    /* shift to upper nible */
  ubDec = ubDec%100;                              /* extract reminder     */
  uwBcd |= (ubDec/10);                            /* extract 10's         */
  uwBcd <<= 4;                                    /* shift to upper nible */
  uwBcd  |= ubDec%10;                             /* extract 1's          */
  return(uwBcd);
} /* LIB_uwDec2Bcd() */


/******************************************************************************* 
* Function   :- LIB_ubDigit2Ascii()
*-------------------------------------------------------------------------------  
* Description:- Converts a Hex digit (0..F) into accompanying ASCII char.
*-------------------------------------------------------------------------------  
* Globals    :-
*-------------------------------------------------------------------------------  
* Parameter  :- Hex value
*-------------------------------------------------------------------------------  
* ReturnValue:- ASCII value
*******************************************************************************/
ubyte LIB_ubDigit2Ascii(ubyte ubDigit)
{
  if(ubDigit > 0x0F)
  {
   // PWR_vAssert(__FILE__, __LINE__);     /* only digits can be converted      */
  }

  ubDigit += 0x30;                       /* shift to first ascii digit '0'    */

  if( ubDigit > 0x39 )                   /* digit was A..F                    */
  {
    ubDigit += 7;                        /* shift again to get ascii 'A'..'F' */
  }
  return(ubDigit);
} /* LIB_ubDigit2Ascii() */


/*******************************************************************************
* Function   :- void LIB_vMemCopy()
*-------------------------------------------------------------------------------
* Description:- Copies the first NumObj bytes of pcvSource array into
*               the first NumObj bytes of pubDestination array.
*               The both arrays must not overlap !
*-------------------------------------------------------------------------------  
* Globals    :-
*-------------------------------------------------------------------------------  
* Parameter(s):- pvDestination : pointer to Destination array
*                pcvSource     : pointer to Source array
*                NumObj        : number of bytes to be copied
*-------------------------------------------------------------------------------
* Returnvalue :- none
*******************************************************************************/
void LIB_vMemCopy(void *pvDestination, const void *pcvSource, 
																																size_t  NumObj)
{
  ubyte *pubDest = (ubyte *)pvDestination;
  const ubyte *pcubSource = (const ubyte *)pcvSource;

  while (NumObj--)
  {
    *pubDest++ = *pcubSource++;
  }
}

/*******************************************************************************
* Function    :- ubyte LIB_ubChkSum()
*-------------------------------------------------------------------------------
* Description :- Calculate the Checksum of Buffer and retunr.
*-------------------------------------------------------------------------------  
* Globals     :-
*-------------------------------------------------------------------------------
* Parameter(s):- pcvSource : pointer to the buffer
*                NumObj    : number of bytes to be add
*-------------------------------------------------------------------------------
* Returnvalue :- ubyte  
*******************************************************************************/
ubyte LIB_ubChkSum(const void *pcvSource, size_t NumObj)  
{
  ubyte ubChkSum;
  const ubyte *pcubSource = (const ubyte *)pcvSource;

  ubChkSum = 0;
  
  while (NumObj--)
  {
    ubChkSum += *pcubSource++;
  }
  return(ubChkSum);
}

/*******************************************************************************
* Function    :- ubyte LIB_ubMemComp()
*-------------------------------------------------------------------------------
* Description :- Compares the first NumObj bytes of pcvSource1 array
*                with the first NumObj bytes of pcvSource2 array.
*-------------------------------------------------------------------------------  
* Globals     :-
*-------------------------------------------------------------------------------
* Parameter(s):- pcvSource1 : pointer to the first array
*                pcvSource2 : pointer to the second array
*                NumObj     : number of bytes to be compared
*-------------------------------------------------------------------------------
* Returnvalue :- ubyte : FALSE (==0) if pcvSource1 equals to pcvSource2
*                        TRUE  (!=0) if pcvSource1 does not equal to
*                                    pcvSource2
*******************************************************************************/
ubyte LIB_ubMemComp(const void *pcvSource1, const void *pcvSource2, 
																																	size_t NumObj)
{
  const ubyte *pcubSource1 = (const ubyte *)pcvSource1;
  const ubyte *pcubSource2 = (const ubyte *)pcvSource2;

  while (NumObj--)
  {
    if( *pcubSource1++ != *pcubSource2++ )
    {
      return(TRUE);       /* unequal */
    }
  }
  return(FALSE);          /* equal */
}

/*******************************************************************************
* Function    :- LIB_STATIC_INLINE void LIB_vMemSet()
*-------------------------------------------------------------------------------
* Description : Sets the first NumObj bytes of the pvDestination array
*              to the passed value cubValue.
*-------------------------------------------------------------------------------  
* Globals     :-	none
*-------------------------------------------------------------------------------
* Parameter(s):- pvDestination : pointer to Destination array
*                cubValue      : value used to set the array bytes
*                NumObj        : number of bytes to be set
*-------------------------------------------------------------------------------
* Returnvalue :- none
*******************************************************************************/
void LIB_vMemSet(void *pvDestination, const ubyte cubValue, 
																																size_t  NumObj)
{
  ubyte *pubDest = (ubyte *)pvDestination;

  while (NumObj--)
  {
    *pubDest++ = cubValue;
  }
}

/*******************************************************************************
* Function    : void LIB_vMemClear()
*-------------------------------------------------------------------------------
* Description : Sets the first NumObj bytes of the pvDestination array to zero.
*-------------------------------------------------------------------------------  
* Globals     :-	none
*-------------------------------------------------------------------------------
* Parameter(s):- pvDestination : pointer to Destination array
*                NumObj        : number of bytes to be cleared
*-------------------------------------------------------------------------------
* Returnvalue :- none
*******************************************************************************/
void LIB_vMemClear(void *pvDestination, size_t  NumObj)
{
  ubyte *pubDest = (ubyte *)pvDestination;

  while (NumObj--)
  {
    *pubDest++ = 0;
  }
}

/******************************************************************************/
/* Changes in version                                                         */
/* $History:  $                                                               */
/******************************************************************************/
/* End of Source File                                                         */
/******************************************************************************/
