#ifndef _GLOBAL_H
#define _GLOBAL_H
/*******************************************************************************
* Filename    :- global.h
* Module      :- Global
*-------------------------------------------------------------------------------  
* Description :- This file defines all types and constants which are
*                common to the whole module library.
*                No symbol defined in this file must be redefined !
*-------------------------------------------------------------------------------  
* Environment :- ARM STM32F100, no OS, compiled with KEIL RealView
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2013 MAPS Technologies, Jaipur         
* Author      :- Mahabir Prasad
*******************************************************************************/ 
/******************************************************************************/
/* Path where it is stored for configuration management                       */
/* $Log:  $                                                                   */
/******************************************************************************/
/******************************************************************************/
/* Includes																																		*/
/******************************************************************************/
#include "cpu_def.h"

/******************************************************************************/
/* Data Size typedef 																													*/
/******************************************************************************/
typedef   signed char  sbyte;     /* 1 byte signed,   type identifier: sb   	*/
typedef unsigned char  ubyte;     /* 1 byte unsigned, type identifier: ub   	*/
typedef   signed short sword;     /* 2 byte signed,   type identifier: sw   	*/
typedef unsigned short uword;     /* 2 byte unsigned, type identifier: uw   	*/
typedef   signed long  slword;    /* 4 byte signed,   type identifier: slw  	*/
typedef unsigned long  ulword;    /* 4 byte unsigned, type identifier: ulw  	*/

/* The following types provide automatic usage of loop counters with        	*/
/* optimum length. Their lenghts depend on the register size of the used    	*/
/* processor. REGISTER_SIZE defined in cpu_def.h.                           	*/

#if (REGISTER_SIZE == NUMBITS_8)
  typedef sbyte smctr;
  typedef ubyte umctr;
#elif (REGISTER_SIZE == NUMBITS_16)
  typedef sword smctr;
  typedef uword umctr;
#elif (REGISTER_SIZE == NUMBITS_32)
  typedef slword smctr;
  typedef ulword umctr;
#else
  #error "unknown register size"
#endif

#ifndef FALSE
  #define FALSE   (0)
  #define TRUE    (!FALSE)
#endif

#ifndef NULL
  #define NULL 0
#endif

/* The following type should be used when functions are accessed via an     	*/
/* of their addresses.                                                      	*/

typedef void  (*fun_vfptrVoid)(void);		/* Function pointer, void as input 		*/
typedef void  (*fun_vfptrUbyte)(ubyte);	/* Function pointer, ubyte as input 	*/

/* Depending on the defined Byte- and Bitorder, the definitions are always  	*/
/* made that way, that the Most Significant Byte (Bit) is the leftmost and  	*/
/* the Least Significant Byte (Bit) is the rightmost.                       	*/

/* Union for Word and Byte access of an area of two Byte length */
typedef union	
{
  uword x;                					/* Word access                            */
  struct                  					/* structure for Byte access              */
  {                            
    #ifdef BYTEORDER_UP   					/* depending on Byteorder                 */
      ubyte l;            					/* Least significant Byte                 */
      ubyte m;            					/* Most significant Byte                  */
    #else                 					/* or */
      ubyte m;            					/* Most significant Byte                  */
      ubyte l;            					/* Least significant Byte                 */
    #endif
  }h;                     					/* name of structure (h = half)           */
}dbyte;                   					/* type name of union                     */

/* Union for Long, Word and Byte access of an area of 4 Byte length */
typedef union
{
  ulword lx;               					/* long word access                      	*/
  struct                   					/* structure for Byte access             	*/
  {
    #ifdef WORDORDER_UP   					/* depending on Wordorder                 */
      dbyte ll;           					/* Least significant Word                 */
      dbyte lm;           					/* Most significant Word                  */
    #else                 					/* or */
      dbyte lm;           					/* Most significant Word                  */
      dbyte ll;           					/* Least significant Word                 */
    #endif
  }lh;                    					/* name of structure (h = half)           */
}dword;                   					/* type name of union                     */


/* Union for Byte and Bit access of an area of 1 Byte length */
typedef union
{
  ubyte bytes;            					/* Byte access                            */
  struct                  					/* structure (bitfield) for Bit access    */
  {
    #ifdef BITORDER_UP              /* depending on Bitorder      						*/
      BITFIELD_TYPE bit0 : 1;       /* LSB first                  						*/
      BITFIELD_TYPE bit1 : 1;
      BITFIELD_TYPE bit2 : 1;
      BITFIELD_TYPE bit3 : 1;
      BITFIELD_TYPE bit4 : 1;
      BITFIELD_TYPE bit5 : 1;
      BITFIELD_TYPE bit6 : 1;
      BITFIELD_TYPE bit7 : 1;       /* MSB last                   						*/
    #else                           /* or */
      BITFIELD_TYPE bit7 : 1;       /* MSB first                  						*/
      BITFIELD_TYPE bit6 : 1;
      BITFIELD_TYPE bit5 : 1;
      BITFIELD_TYPE bit4 : 1;
      BITFIELD_TYPE bit3 : 1;
      BITFIELD_TYPE bit2 : 1;
      BITFIELD_TYPE bit1 : 1;
      BITFIELD_TYPE bit0 : 1;       /* LSB last                   						*/
    #endif
  }bits;                   					/* name of structure (bitfield)           */
}breg;                     					/* type name of union                     */

/* Union for Word, Byte and Bit access of an area of 2 Byte length */
typedef union
{
  dbyte words;            					/* Word and Byte access (see dbyte above) */
  struct                  					/* structure (bitfield) for Bit access    */
  {
    #ifdef BITORDER_UP              /* depending on Bitorder      						*/
      BITFIELD_TYPE bit0  : 1;      /* LSB first                  						*/
      BITFIELD_TYPE bit1  : 1;
      BITFIELD_TYPE bit2  : 1;
      BITFIELD_TYPE bit3  : 1;
      BITFIELD_TYPE bit4  : 1;
      BITFIELD_TYPE bit5  : 1;
      BITFIELD_TYPE bit6  : 1;
      BITFIELD_TYPE bit7  : 1;
      BITFIELD_TYPE bit8  : 1;
      BITFIELD_TYPE bit9  : 1;
      BITFIELD_TYPE bit10 : 1;
      BITFIELD_TYPE bit11 : 1;
      BITFIELD_TYPE bit12 : 1;
      BITFIELD_TYPE bit13 : 1;
      BITFIELD_TYPE bit14 : 1;
      BITFIELD_TYPE bit15 : 1;      /* MSB last                   						*/
    #else                           /* or */
      BITFIELD_TYPE bit15 : 1;      /* MSB first                  						*/
      BITFIELD_TYPE bit14 : 1;
      BITFIELD_TYPE bit13 : 1;
      BITFIELD_TYPE bit12 : 1;
      BITFIELD_TYPE bit11 : 1;
      BITFIELD_TYPE bit10 : 1;
      BITFIELD_TYPE bit9  : 1;
      BITFIELD_TYPE bit8  : 1;
      BITFIELD_TYPE bit7  : 1;
      BITFIELD_TYPE bit6  : 1;
      BITFIELD_TYPE bit5  : 1;
      BITFIELD_TYPE bit4  : 1;
      BITFIELD_TYPE bit3  : 1;
      BITFIELD_TYPE bit2  : 1;
      BITFIELD_TYPE bit1  : 1;
      BITFIELD_TYPE bit0  : 1;      /* LSB last                   						*/
    #endif
  }w_bits;                 					/* name of structure (bitfield)           */
}wreg;                     					/* type name of union                     */

/* Union for Word, Byte and Bit access of an area of 4 Byte length */
typedef union
{
  dword longs;            					/* Word and Byte access (see dbyte above) */
  struct                  					/* structure (bitfield) for Bit access    */
  {
    #ifdef BITORDER_UP              /* depending on Bitorder      */
      BITFIELD_TYPE bit0  : 1;      /* LSB first                  */
      BITFIELD_TYPE bit1  : 1;
      BITFIELD_TYPE bit2  : 1;
      BITFIELD_TYPE bit3  : 1;
      BITFIELD_TYPE bit4  : 1;
      BITFIELD_TYPE bit5  : 1;
      BITFIELD_TYPE bit6  : 1;
      BITFIELD_TYPE bit7  : 1;
      BITFIELD_TYPE bit8  : 1;
      BITFIELD_TYPE bit9  : 1;
      BITFIELD_TYPE bit10 : 1;
      BITFIELD_TYPE bit11 : 1;
      BITFIELD_TYPE bit12 : 1;
      BITFIELD_TYPE bit13 : 1;
      BITFIELD_TYPE bit14 : 1;
      BITFIELD_TYPE bit15 : 1;
      BITFIELD_TYPE bit16 : 1;
      BITFIELD_TYPE bit17 : 1;
      BITFIELD_TYPE bit18 : 1;
      BITFIELD_TYPE bit19 : 1;
      BITFIELD_TYPE bit20 : 1;
      BITFIELD_TYPE bit21 : 1;
      BITFIELD_TYPE bit22 : 1;
      BITFIELD_TYPE bit23 : 1;
      BITFIELD_TYPE bit24 : 1;
      BITFIELD_TYPE bit25 : 1;
      BITFIELD_TYPE bit26 : 1;
      BITFIELD_TYPE bit27 : 1;
      BITFIELD_TYPE bit28 : 1;
      BITFIELD_TYPE bit29 : 1;
      BITFIELD_TYPE bit30 : 1;
      BITFIELD_TYPE bit31 : 1;      /* MSB last                   						*/
    #else                           /* or 																		*/
      BITFIELD_TYPE bit31 : 1;      /* MSB first                  						*/
      BITFIELD_TYPE bit30 : 1;
      BITFIELD_TYPE bit29 : 1;
      BITFIELD_TYPE bit28 : 1;
      BITFIELD_TYPE bit27 : 1;
      BITFIELD_TYPE bit26 : 1;
      BITFIELD_TYPE bit25 : 1;
      BITFIELD_TYPE bit24 : 1;
      BITFIELD_TYPE bit23 : 1;
      BITFIELD_TYPE bit22 : 1;
      BITFIELD_TYPE bit21 : 1;
      BITFIELD_TYPE bit20 : 1;
      BITFIELD_TYPE bit19 : 1;
      BITFIELD_TYPE bit18 : 1;
      BITFIELD_TYPE bit17 : 1;
      BITFIELD_TYPE bit16 : 1;
      BITFIELD_TYPE bit15 : 1;
      BITFIELD_TYPE bit14 : 1;
      BITFIELD_TYPE bit13 : 1;
      BITFIELD_TYPE bit12 : 1;
      BITFIELD_TYPE bit11 : 1;
      BITFIELD_TYPE bit10 : 1;
      BITFIELD_TYPE bit9  : 1;
      BITFIELD_TYPE bit8  : 1;
      BITFIELD_TYPE bit7  : 1;
      BITFIELD_TYPE bit6  : 1;
      BITFIELD_TYPE bit5  : 1;
      BITFIELD_TYPE bit4  : 1;
      BITFIELD_TYPE bit3  : 1;
      BITFIELD_TYPE bit2  : 1;
      BITFIELD_TYPE bit1  : 1;
      BITFIELD_TYPE bit0  : 1;      /* LSB last                   						*/
    #endif
  }l_bits;                 					/* name of structure (bitfield)           */
}lreg;                     					/* type name of union                     */

/* Union for Word and Bit access of an area of two Byte length */
typedef union
{
  uword x;                					/* Word access                            */
  struct                  					/* structure for Byte access              */
  {
    #ifdef BYTEORDER_UP   					/* depending on Byteorder                 */
      breg  l;            					/* Least significant Byte                 */
      breg  m;            					/* Most significant Byte                  */
    #else                 					/* or */
      breg  m;            					/* Most significant Byte                  */
      breg  l;            					/* Least significant Byte                 */
    #endif
  }h;                     					/* name of structure (h = half)           */
}dbreg;                   					/* type name of union                     */

/*******************************************************************************
* Defines
*******************************************************************************/
#define ON        			1
#define OFF       			0

#define SET       			1
#define CLEAR     			0

#define GLB_VALID      	1
#define GLB_INVALID    	2

/******************************************************************************/
/* Makro definitions																													*/
/******************************************************************************/
//#define SET_BIT(var,mask) ((var) |= (mask))  /* set masked bit(s) in var    */
//#define CLR_BIT(var,mask) ((var) &= ~(mask)) /* clear masked bit(s) in var  */
//#define CHG_BIT(var,mask) ((var) ^= (mask))  /* change masked bit(s) in var */
//#define CHK_BIT(var,mask) ((var) &  (mask))  /* check masked bit(s) in var  */


/* the following four macros work with unsigned and signed data types for   */
/* the parameters, convert the BCD value to ASCII in two bytes  */
#define GLB_HINIBLE(b)    (((b) & 0xF0) >> 4)
#define GLB_LONIBLE(b)    ((b) & 0x0F)
#define GLB_HIASCII(b)    (GLB_HINIBLE(b) + 0x30)
#define GLB_LOASCII(b)    (GLB_LONIBLE(b) + 0x30)
#define GLB_ASCII(b)      ((b) + 0x30) // hex to ascii

/* the following four macros work with unsigned and signed data types for   */
/* the parameters w=word and lw=long word */
#define GLB_HIBYTE(w)     ( (ubyte) (((uword)(w)) >> 8) )
#define GLB_LOBYTE(w)     ( (ubyte) (((uword)(w)) &  0xFF) )
#define GLB_HIWORD(lw)    ( (uword) (((ulword)(lw)) >> 16) )
#define GLB_LOWORD(lw)    ( (uword) (((ulword)(lw)) &  0xFFFF) )

/* the following two macros work with unsigned and signed data types for    */
/* the parameters hib, lob=byte and hiw,low=word */
#define GLB_WORD(hib,lob)   ((((uword)(hib))  << 8)  + ((uword)(lob)) )
#define GLB_DWORD(hiw,low)  ((((ulword)(hiw)) << 16) + ((ulword)(low)) )

#define GLB_BCD_PACK(hib, lob)   ((((ubyte)(hib)) << 4)  + ((ubyte)(lob)))

/*============================================================================*/
/* Following macros provides the bigest and the lowest value of a or b        */
/* respectively.                                                              */
/*----------------------------------------------------------------------------*/
#define GLB_MAX(a,b) ((a) > (b) ? (a) : (b))
#define GLB_MIN(a,b) ((a) < (b) ? (a) : (b))
/*============================================================================*/
/* Following macro swap values a or b        																	*/
/*----------------------------------------------------------------------------*/
#define SWAP(a, b)  {a ^= b; b ^= a; a ^= b;}

typedef struct
{ 
  ubyte ubSecond;
  ubyte ubMinute;       
  ubyte ubHour;         
} GLB_TY_Time;

/* GLB_TY_TimeDate declares a structure which contains all necessary    */
/* information regarding the time, date and the validity of the time    */
/* This structure is part of GLB_TY_InterfaceStruct which is necessary  */
/* to exchange data with the real time clock                            */

typedef struct
{ 
  ubyte ubSecond;
  ubyte ubMinute;       
  ubyte ubHour;         

  ubyte ubWeekDay;      

  ubyte ubDay;
  ubyte ubMonth;        
  ubyte ubYear;         

  ubyte ubValidity;
} GLB_TY_TimeDate;

/* GLB_TY_GPIC declares a structure which contains all necessary        			*/
/* information to handle static graphic and animation structure for     			*/
/* the display                                                          			*/

typedef struct stGPIC
{
  const ubyte *pubSubGraphic;     	/* Pointer to the SubGraphic          		*/
  const ubyte ubXPos;             	/* X-Position of Graphic on LCD       		*/ 
  const ubyte ubYPos;             	/* Y-Position of Graphic on LCD       		*/      
  const ubyte ubDx;               	/* size of teh Graphic in X-Direction 		*/
  const ubyte ubHandling;         	/* Handling of Graphic on LCD         		*/ 
  const struct stGPIC *pstNext;   	/* Pointer to next Graphic Structure  		*/
} GLB_TY_GPIC;

/* GLB_TY_InterfaceStruct declares a global structure which is used to  			*/
/* pass/get parameters to/from complex function-interfaces              			*/
/* Note that it is not allowed to access the structure directly by      			*/
/* writing or reading structure members. Use always the get/set-macros  			*/
/* which allow access to all the structure members. This allows a high  			*/
/* flexibillity of the structure and makes it possible to add new       			*/
/* members or to change the order                                       			*/

typedef struct 
{
  /* This union contains the get data which is returned by the function */
  union
  {
    ubyte             ub;
    sbyte             sb;
    uword             uw;
    sword             sw;
    dbyte             db;
    ulword            ulw;
    ubyte             *pubSource; 
    uword             *puwSource; 
    GLB_TY_TimeDate   tyTimeDate;
    GLB_TY_GPIC       *tyGpic;
  }unResult;

  /* If a pointer pubSource or puwSource is used in unResult, the length*/
  /* of the data is passed in ubBufferLength                            */
  ubyte        ubBufferLength; 

               /* This is an additional information for the return      */
               /* value given by the called function. It is used in     */
               /* very special cases only (e.g. Tuner returns frequency */
               /* or PS-name specified by ubTypeOfInfo)                 */
  ubyte        ubTypeOfInfo; 
 
               /* An interface normaly provides a large set of return   */
               /* values (e.g AUD_GET_BASS, AUD_GET_TREBLE,             */
               /* AUD_GET_BALANCE, ...). uwIndex addresses a single     */
               /* element out of this set                               */
               /* uwIndex is always set by the calling function of the  */
               /* interface                                             */
  uword        uwIndex; 

               /* ubID holds the number of the data source, if there    */
               /* are several sub-components encapsulted by the         */
               /* interface function (e.g. two tuners)                  */
  ubyte        ubID;

               /* uiUpdateFlag informs the caller of the interface      */
               /* function if the data has been changed since the last  */
               /* get-access                                            */
  unsigned int uiUpdateFlag:1; 

} GLB_TY_InterfaceStruct;

/* These are the set/get-macros for accessing the members of the        */
/* GLB_TY_InterfaceStruct                                               */

/*---------------------------------------------------------------------
   Macros accessing unResult section without tyTimeDate
---------------------------------------------------------------------*/

/* set macros */

#define GLB_vSetResultByte(Target,Value) \
  ((Target)->unResult.ub = (Value))

#define GLB_vSetResultSByte(Target,Value) \
  ((Target)->unResult.sb = (Value))

#define GLB_vSetResultWord(Target,Value) \
  ((Target)->unResult.uw = (Value))

#define GLB_vSetResultSWord(Target,Value) \
  ((Target)->unResult.sw = (Value))

#define GLB_vSetResultHighByte(Target,Value) \
  ((Target)->unResult.db.h.m = (Value))

#define GLB_vSetResultLowByte(Target,Value) \
  ((Target)->unResult.db.h.l = (Value))

#define GLB_vSetResultLongWord(Target,Value) \
  ((Target)->unResult.ulw = (Value))

#define GLB_vSetResultBytePointer(Target,Value) \
  ((Target)->unResult.pubSource = (Value))

#define GLB_vSetResultWordPointer(Target,Value) \
  ((Target)->unResult.puwSource = (Value))

/* get macros */

#define GLB_ubGetResultByte(Target) \
  ((Target)->unResult.ub)

#define GLB_sbGetResultSByte(Target) \
  ((Target)->unResult.sb)

#define GLB_uwGetResultWord(Target) \
  ((Target)->unResult.uw)

#define GLB_swGetResultSWord(Target) \
  ((Target)->unResult.sw)

#define GLB_ubGetResultHighByte(Target) \
  ((ubyte)((Target)->unResult.db.h.m))

#define GLB_ubGetResultLowByte(Target) \
  ((ubyte)((Target)->unResult.db.h.l))

#define GLB_ulwGetResultLongWord(Target) \
  ((Target)->unResult.ulw)

#define GLB_pubGetResultBytePointer(Target) \
  ((Target)->unResult.pubSource)

#define GLB_puwGetResultWordPointer(Target) \
  ((Target)->unResult.puwSource)

  
/*---------------------------------------------------------------------
   Macros accessing tyTimeDate
---------------------------------------------------------------------*/

/* set macros */

#define GLB_vSetYearData(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubYear = (Value))

#define GLB_vSetMonthData(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubMonth = (Value))

#define GLB_vSetDayData(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubDay = (Value))

#define GLB_vSetHourData(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubHour = (Value))

#define GLB_vSetMinuteData(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubMinute = (Value))

#define GLB_vSetSecondData(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubSecond = (Value))

#define GLB_vSetWeekDay(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubWeekDay = (Value))

#define GLB_vSetClkValidity(Target,Value) \
  ((Target)->unResult.tyTimeDate.ubValidity = (Value))


/* get macros */
       
#define GLB_ubGetYearData(Target) \
  ((Target)->unResult.tyTimeDate.ubYear) 

#define GLB_ubGetMonthData(Target) \
  ((Target)->unResult.tyTimeDate.ubMonth) 

#define GLB_ubGetDayData(Target) \
  ((Target)->unResult.tyTimeDate.ubDay) 

#define GLB_ubGetHourData(Target) \
  ((Target)->unResult.tyTimeDate.ubHour) 

#define GLB_ubGetMinuteData(Target) \
  ((Target)->unResult.tyTimeDate.ubMinute) 

#define GLB_ubGetSecondData(Target) \
  ((Target)->unResult.tyTimeDate.ubSecond) 

#define GLB_ubGetWeekDayData(Target) \
  ((Target)->unResult.tyTimeDate.ubWeekDay) 

#define GLB_ubGetClkValidityData(Target) \
 ((Target)->unResult.tyTimeDate.ubValidity) 

/*---------------------------------------------------------------------
   Macros accessing variables for additional information
---------------------------------------------------------------------*/
/* set macros */

#define GLB_vSetBufferLength(Target,Value) \
  ((Target)->ubBufferLength = (Value))

#define GLB_vSetTypeOfInfo(Target,Value) \
  ((Target)->ubTypeOfInfo = (Value))

#define GLB_vSetIndex(Target,Value) \
  ((Target)->uwIndex = ((uword)(Value)))

#define GLB_vSetIndexWord(Target,Value) \
  ((Target)->uwIndex = (Value))

#define GLB_vSetID(Target,Value) \
  ((Target)->ubID = (Value))

#define GLB_vSetUpdateFlag(Target,Value) \
  ((Target)->uiUpdateFlag |= (Value))


/* get macros */

#define GLB_ubGetBufferLength(Target) \
  ((Target)->ubBufferLength)

#define GLB_ubGetTypeOfInfo(Target) \
  ((Target)->ubTypeOfInfo)

#define GLB_ubGetIndex(Target) \
  ((ubyte) ((Target)->uwIndex))

#define GLB_uwGetIndexWord(Target) \
  ((Target)->uwIndex)

#define GLB_ubGetID(Target) \
  ((Target)->ubID)

#define GLB_ubGetUpdateFlag(Target) \
  ((Target)->uiUpdateFlag)

/******************************************************************************/
#endif                                                         	 /* _GLOBAL_H */
/******************************************************************************/
/* Changes in version                                                         */
/* $History:  $                                                               */
/******************************************************************************/
/* End of Header File                                                         */
/******************************************************************************/
