#ifndef _CPU_DEF_H
#define _CPU_DEF_H
/*******************************************************************************
* Filename    :- cpu_def.h
* Module      :- System
*-------------------------------------------------------------------------------  
* Description :- this file is always the first include in each source 
*                file. It defines symbols for compilation of the 
*                modules in different envirements.
*-------------------------------------------------------------------------------  
* Environment :- ARM STM32F100, no OS, compiled with KEIL RealView
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2013 MAPS Technologies, Jaipur         
* Author      :- Mahabir Prasad
*******************************************************************************/ 
/******************************************************************************/
/* Path where it is stored for configuration management                       */
/* $Log:  $                                                                   */
/******************************************************************************/

/******************************************************************************/ 
/* possible processors																												*/
/******************************************************************************/ 
#define PC      			1           /* to create Code, which is PC testable*/
#define	LPC						2
#define	STM32					3

/******************************************************************************/ 
/* possible processor subtypes																								*/
/******************************************************************************/ 
#define LPC213	  		1
#define LPC214	  		2

/******************************************************************************/
/* possible register sizes																										*/
/******************************************************************************/
#define NUMBITS_8    	1
#define NUMBITS_16   	2
#define NUMBITS_32   	3

/******************************************************************************/
/* possible Board Types																												*/
/******************************************************************************/ 
#define LPC_LED				1

/******************************************************************************/ 
/* operating system which is used in the SW																		*/
/******************************************************************************/ 

/******************************************************************************/ 
/* current target system																											*/
/******************************************************************************/ 
#define PROCESSOR     PC
#define REGISTER_SIZE NUMBITS_32 /* only important if types for loop counters */
                                 /* of optimum length (see global.h) are used */
                                 /* NUMBITS_8 for AVR8                        */
                                 /* NUMBITS_16 for dsPIC                      */

/******************************************************************************/
/* order of bits in a bitfield, order of bytes in a word											*/
/******************************************************************************/
#if (PROCESSOR == PC)
  #define BITORDER_UP
  #define BYTEORDER_UP
  #define WORDORDER_UP     
  #define BITFIELD_TYPE unsigned int

#elif (PROCESSOR == LPC)
  #define BITORDER_UP
  #define BYTEORDER_UP
  #define WORDORDER_UP
  #define BITFIELD_TYPE unsigned int

#elif (PROCESSOR == STM32)
  #define BITORDER_UP
  #define BYTEORDER_UP
  #define WORDORDER_UP
  #define BITFIELD_TYPE unsigned short

#else
  #error unknown processor
#endif

/******************************************************************************/
/* low / high, input / output status of IO																		*/
/******************************************************************************/
#define	SYS_LOW			0
#define	SYS_HIGH		1
#define	SYS_INPUT		0
#define	SYS_OUTPUT	1

/******************************************************************************/
#endif                                                          /* _CPU_DEF_H */
/******************************************************************************/
/* Changes in version                                                         */
/* $History:  $                                                               */
/******************************************************************************/
/* End of Header File                                                         */
/******************************************************************************/
