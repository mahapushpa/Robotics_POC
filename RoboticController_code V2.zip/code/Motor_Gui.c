#include <gtk/gtk.h>
#include <string.h>

#include "global.h"
#include "Motor.h"


/* ------------------------------------------------------------------------- */
// gcc Motor_Gui.c $(pkg-config --cflags --libs gtk+-2.0) -o Motor_Gui
/* ------------------------------------------------------------------------- */
GtkWidget *comboBoxDirection[ cMaxMotors ];
GtkWidget *comboBoxSpeed[ cMaxMotors ];
GtkWidget *StartStopBtn[ cMaxMotors ];

ubyte MotorData[ cMaxMotors * 2u ];
/* ------------------------------------------------------------------------- */ 
static void MotorButtonClicked(
  GtkWidget *widget, 
  gpointer data) ;
  
static gint close_application( 
  GtkWidget *widget,
  GdkEvent *event,
  gpointer data );  
  
static void stopAllMotors( GtkWidget *widget );  
  
static void CreateComboBoxDirection( ubyte Idx_p );
static void CreateComboBoxSpeed( ubyte Idx_p );
static void ReadMotorDataFromFile( ubyte aBuff_p[ ] );

static void writeMotorDataInFile( 
  ubyte MotorId_p, 
  ubyte Speed_p, 
  ubyte Direction_p );
  
/* ------------------------------------------------------------------------- */
void MotorGuiMain_g( void )
{
    
  GtkWidget *window;
  GtkWidget *table;
  GtkWidget *main_vbox;
  GtkWidget *frame;
  GtkWidget *vbox;
  GtkWidget *vbox2;
  GtkWidget *hbox;  
  GtkWidget *button;
  GtkWidget *label;
  
  GtkAdjustment *adj;
    
  gtk_init( NULL, NULL );
  
  ReadMotorDataFromFile( MotorData );
  
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 900, 600);
  gtk_window_set_title(GTK_WINDOW(window), "Robotics Arm Controller V0.1");
  
  gtk_container_set_border_width(GTK_CONTAINER(window), 20);
  /* create the main Box */
  main_vbox = gtk_vbox_new (FALSE, 1);
  gtk_container_set_border_width (GTK_CONTAINER (main_vbox), 10);
  gtk_container_add (GTK_CONTAINER (window), main_vbox);
  
  /* create motor 1 frame */
  frame = gtk_frame_new ("Motor 1 ");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxSpeed( eMotor_1 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_1 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxDirection( eMotor_1 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_1 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_1 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_1 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_1 );
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_1 ], FALSE, TRUE, 0);
  
  /* create motor 2 frame */
  frame = gtk_frame_new ("Motor 2 ");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxSpeed( eMotor_2 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_2 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxDirection( eMotor_2 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_2 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_2 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_2 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_2 );
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_2 ], FALSE, TRUE, 0);
  
   /* create motor 3 frame */
  frame = gtk_frame_new ("Motor 3 ");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);

  CreateComboBoxSpeed( eMotor_3 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_3 ], FALSE, TRUE, 0);
 
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxDirection( eMotor_3 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_3 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_3 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_3 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_3);
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_3 ], FALSE, TRUE, 0);

  /* create motor 4 frame */
  frame = gtk_frame_new ("Motor 4 ");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);

  CreateComboBoxSpeed( eMotor_4 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_4 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxDirection( eMotor_4 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_4 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_4 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_4 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_4 );
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_4 ], FALSE, TRUE, 0); 

  /* create motor 5 frame */
  frame = gtk_frame_new ("Motor 5");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxSpeed( eMotor_5 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_5 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxDirection( eMotor_5 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_5 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_5 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_5 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_5);
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_5 ], FALSE, TRUE, 0);

  /* create motor 6 frame */
  frame = gtk_frame_new ("Motor 6 ");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxSpeed( eMotor_6 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_6 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);

  CreateComboBoxDirection( eMotor_6 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_6 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_6 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_6 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_6);
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_6 ], FALSE, TRUE, 0);
  
   /* create motor 7 frame */
  frame = gtk_frame_new ("Motor 7 ");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE, TRUE, 5);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Speed(rpm) :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxSpeed( eMotor_7 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxSpeed[ eMotor_7 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("Direction :");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  CreateComboBoxDirection( eMotor_7 );
  gtk_box_pack_start (GTK_BOX (vbox2), comboBoxDirection[ eMotor_7 ], FALSE, TRUE, 0);
  
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
  
  label = gtk_label_new ("");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
  
  StartStopBtn[ eMotor_7 ] = gtk_button_new_with_label ("Start");
  g_signal_connect (G_OBJECT (StartStopBtn[ eMotor_7 ]), "clicked", G_CALLBACK (MotorButtonClicked), eMotor_7);
  gtk_box_pack_start (GTK_BOX (vbox2), StartStopBtn[ eMotor_7 ], FALSE, TRUE, 0); 
  
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, TRUE, 0);
  button = gtk_button_new_with_label ("Stop All");
  g_signal_connect_swapped (G_OBJECT (button), "clicked", G_CALLBACK (stopAllMotors), G_OBJECT (window));
  gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 5);

  g_signal_connect(G_OBJECT(window), "destroy",
        G_CALLBACK(close_application), G_OBJECT(window));

  gtk_widget_show_all(window);

  gtk_main( );

  return 0;
}
/* ------------------------------------------------------------------------- */
static gint close_application( 
  GtkWidget *widget,
  GdkEvent *event,
  gpointer data )
{
  ubyte Idx;
  stMotordrive Motordriver;
  
  // stop motor and put all pins in Input state 
  for( Idx = 0u; Idx < cMaxMotors; Idx++ )
  {
    InitMotorGPIO_g( Idx, 0u, Motordriver );
  }  
   
  g_print("close windows \n" );
  gtk_widget_destroy( widget );
  return FALSE;
}
/* ------------------------------------------------------------------------- */
static void stopAllMotors( GtkWidget *widget )
{
  ubyte Idx;
  stMotordrive Motordriver;
  
  // stop motor and put all pins in Input state 
  for( Idx = 0u; Idx < cMaxMotors; Idx++ )
  {
    InitMotorGPIO_g( Idx, 0u, Motordriver );
    gtk_button_set_label( (GtkButton*)StartStopBtn[ Idx ], "Start");
  } 
}
/* ------------------------------------------------------------------------- */
static void CreateComboBoxDirection( ubyte Idx_p )
{
  comboBoxDirection[ Idx_p ] = gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxDirection[ Idx_p ]), "Forword");
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxDirection[ Idx_p ]), "Reverse");
  gtk_combo_box_set_active( comboBoxDirection[ Idx_p ], MotorData[ (Idx_p *2u) + 1u ] );
}
/* ------------------------------------------------------------------------- */
static void CreateComboBoxSpeed( ubyte Idx_p )
{
  comboBoxSpeed[ Idx_p ] = gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxSpeed[ Idx_p ]), "150");
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxSpeed[ Idx_p ]), "75");
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxSpeed[ Idx_p ]), "60");
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxSpeed[ Idx_p ]), "50");
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxSpeed[ Idx_p ]), "30");
  gtk_combo_box_append_text(GTK_COMBO_BOX(comboBoxSpeed[ Idx_p ]), "20");
  
  gtk_combo_box_set_active( comboBoxSpeed[ Idx_p ], MotorData[ (Idx_p *2u) ] );
}
/* ------------------------------------------------------------------------- */
const ubyte MotoronOffDuty[ 6u ][ 2u ] = 
{
  1u, 1u,  // 150 rpm
  2u, 2u,  // 75 rpm
  2u, 3u,  // 60 rpm
  2u, 4u,  // 50 rpm
  4u, 6u,  // 30 rpm
  5u, 10u  // 20 rpm
};

static void MotorButtonClicked(
  GtkWidget *Button, 
  gpointer data) 
{    
  ubyte* Btnlabel;
  ubyte MotorId;
  ubyte MotorState;
  
  stMotordrive Motordriver;
  
  ubyte speed;
  ubyte Direction;
  
  MotorId = (ubyte)data;

  speed = gtk_combo_box_get_active ( comboBoxSpeed[ MotorId ] );
  Direction = gtk_combo_box_get_active ( comboBoxDirection[ MotorId ] );
  Btnlabel = gtk_button_get_label ( Button );  
  g_print("clicked-1 = %d, Speed = %d, Direction = %d\n", data, speed, Direction );
//  g_print("Lable = %s\n", Btnlabel );

  if( 0u == strcmp( "Start", Btnlabel ) )
  {
    gtk_button_set_label( (GtkButton*)Button, "Stop");
    MotorState = eRun;
    writeMotorDataInFile( MotorId, speed, Direction );
  }
  else
  {
    gtk_button_set_label( (GtkButton*)Button, "Start");
    MotorState = eStoped;
  }
  
  Motordriver.State = MotorState;
  Motordriver.Direction = Direction;
  Motordriver.SpeedOnTime = MotoronOffDuty[ speed ][ 0u ];
  Motordriver.SpeedOffTime = MotoronOffDuty[ speed ][ 1u ];
    
  if( MotorState == eRun )
  {  
    InitMotorGPIO_g( MotorId, 1u, Motordriver );
  }
  else
  { // stop motor and put all pins in Input state 
    InitMotorGPIO_g( MotorId, 0u, Motordriver );
  }
}
/* ------------------------------------------------------------------------- */
static void writeMotorDataInFile( 
  ubyte MotorId_p, 
  ubyte Speed_p, 
  ubyte Direction_p )
{
  FILE *fptr;
  ubyte Idx = MotorId_p * 2u;
  ubyte Data[ 14u ]; /* each motor speed and direction is saved, total 7 motors */
  
  if ((fptr = fopen("data.bin","rb+")) == NULL)
  {
    ReadMotorDataFromFile( Data );
    g_print("can not able to open file \n" );
  }
  else
  {
    fread( Data, 14u, 1u, fptr );
    fclose(fptr);
    Data[ Idx ] = Speed_p;
    Data[ Idx + 1u] = Direction_p; 
    
    if ((fptr = fopen("data.bin","wb")) != NULL)
    {
      fwrite(Data, 14u, 1u, fptr);
    }
    else
    {
      g_print("can not able to open file \n" );
    }
    g_print("data updated in file = %d\n", MotorId_p );
  }
  
  fclose(fptr);
}
/* ------------------------------------------------------------------------- */
static void ReadMotorDataFromFile( ubyte aBuff_p[ ] )
{
  FILE *fptr;
  ubyte defaultData[ 14u ] = { 3u, 0u, 3u, 0u, 3u, 0u, 3u, 0u, 3u, 0u, 3u, 0u, 3u, 0u };
  ubyte i;
  
  if ((fptr = fopen("data.bin","rb")) == NULL)
  {
    g_print("can not able to open file \n" );
    if ((fptr = fopen("data.bin","wb")) != NULL)
    {   
      fwrite(defaultData, 14u, 1u, fptr);
      g_print("New file created with default data \n" );
    }
  }
  else
  {
    fread(aBuff_p, 14u, 1u, fptr);
    for( i =0u; i <14; i++ )
    {
      g_print( "%d", aBuff_p[ i ]);
    }
    g_print("got last saved data \n" );
  }
  
  fclose(fptr);
}
