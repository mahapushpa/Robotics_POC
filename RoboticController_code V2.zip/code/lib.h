#ifndef _LIB_H
#define _LIB_H
/*******************************************************************************
* Filename   :- lib.h
* Module     :- function library
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2008 Embedded Ashram, Jaipur         
* Author      :- Mahabir Prasad
*-------------------------------------------------------------------------------
* Description :- Contains configuration switches and inline functions.
*-------------------------------------------------------------------------------  
* Environment :- ARM STM32F100, no OS, compiled with KEIL RealView
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2013 MAPS Technologies, Jaipur         
*******************************************************************************/ 
/******************************************************************************/
/* Path where it is stored for configuration management                       */
/* $Log:  $                                                                   */
/******************************************************************************/

/******************************************************************************/
/* Includes																																		*/
/******************************************************************************/
#include <stddef.h>                                            /* type size_t */

/*******************************************************************************
* Defines
*******************************************************************************/

/******************************************************************************/
/* Inline handling                                                            */
/******************************************************************************/

/*******************************************************************************
* Typedefs / structs / unions
*******************************************************************************/
//typedef slword  signed_size_t;


/******************************************************************************/
/* Inline functions																														*/
/******************************************************************************/

/*******************************************************************************
* Function   :- void LIB_vMemCopy()
*-------------------------------------------------------------------------------
* Description:- Copies the first NumObj bytes of pcvSource array into
*               the first NumObj bytes of pubDestination array.
*               The both arrays must not overlap !
*-------------------------------------------------------------------------------  
* Globals    :-
*-------------------------------------------------------------------------------  
* Parameter(s):- pvDestination : pointer to Destination array
*                pcvSource     : pointer to Source array
*                NumObj        : number of bytes to be copied
*-------------------------------------------------------------------------------
* Returnvalue :- none
*******************************************************************************/
void LIB_vMemCopy(void *pvDestination, const void *pcvSource, size_t  NumObj);

/*******************************************************************************
* Function    :- ubyte LIB_ubChkSum()
*-------------------------------------------------------------------------------
* Description :- Calculate the Checksum of Buffer and retunr.
*-------------------------------------------------------------------------------  
* Globals     :-
*-------------------------------------------------------------------------------
* Parameter(s):- pcvSource : pointer to the buffer
*                NumObj    : number of bytes to be add
*-------------------------------------------------------------------------------
* Returnvalue :- ubyte  
*******************************************************************************/
ubyte LIB_ubChkSum(const void *pcvSource, size_t NumObj) ;


/*******************************************************************************
* Function    :- ubyte LIB_ubMemComp()
*-------------------------------------------------------------------------------
* Description :- Compares the first NumObj bytes of pcvSource1 array
*                with the first NumObj bytes of pcvSource2 array.
*-------------------------------------------------------------------------------  
* Globals     :-
*-------------------------------------------------------------------------------
* Parameter(s):- pcvSource1 : pointer to the first array
*                pcvSource2 : pointer to the second array
*                NumObj     : number of bytes to be compared
*-------------------------------------------------------------------------------
* Returnvalue :- ubyte : FALSE (==0) if pcvSource1 equals to pcvSource2
*                        TRUE  (!=0) if pcvSource1 does not equal to
*                                    pcvSource2
*******************************************************************************/
ubyte LIB_ubMemComp(const void *pcvSource1, const void *pcvSource2, size_t NumObj);


/*******************************************************************************
* Function    :- LIB_STATIC_INLINE void LIB_vMemSet()
*-------------------------------------------------------------------------------
* Description : Sets the first NumObj bytes of the pvDestination array
*              to the passed value cubValue.
*-------------------------------------------------------------------------------  
* Globals     :-	none
*-------------------------------------------------------------------------------
* Parameter(s):- pvDestination : pointer to Destination array
*                cubValue      : value used to set the array bytes
*                NumObj        : number of bytes to be set
*-------------------------------------------------------------------------------
* Returnvalue :- none
*******************************************************************************/
void LIB_vMemSet(void *pvDestination, const ubyte cubValue, size_t  NumObj);


/*******************************************************************************
* Function    : void LIB_vMemClear()
*-------------------------------------------------------------------------------
* Description : Sets the first NumObj bytes of the pvDestination array to zero.
*-------------------------------------------------------------------------------  
* Globals     :-	none
*-------------------------------------------------------------------------------
* Parameter(s):- pvDestination : pointer to Destination array
*                NumObj        : number of bytes to be cleared
*-------------------------------------------------------------------------------
* Returnvalue :- none
*******************************************************************************/
void LIB_vMemClear(void *pvDestination, size_t  NumObj);

/******************************************************************************/
/* Prototypes for functions in LIB.C                                          */
/******************************************************************************/
#if 1                                   /* we want to have one function only; */
                                        /* the second is generated as a macro */
ubyte LIB_ubBcd2Dec(ubyte ubHex);

#define LIB_uwBcd2Dec(uwHex) ( (((uword)LIB_ubBcd2Dec(GLB_HIBYTE(uwHex)))*100)\
                              + ((uword)LIB_ubBcd2Dec(GLB_LOBYTE(uwHex))) )
#else
  uword LIB_uwBcd2Dec(uword uwHex);

  #define LIB_ubBcd2Dec(ubHex) ( GLB_LOBYTE(LIB_uwBcd2Dec(ubHex)) )
#endif

ubyte LIB_ubDigit2Ascii(ubyte ubDigit);
ubyte LIB_ubDec2Bcd(ubyte ubDec); // 2 Digits (00--99)
uword LIB_uwDec2Bcd(ubyte ubDec); // 3 digits (0--255)

/******************************************************************************/
#endif                                                         	 	  /* _LIB_H */
/******************************************************************************/
/* Changes in version                                                         */
/* $History:  $                                                               */
/******************************************************************************/
/* End of Header File                                                         */
/******************************************************************************/
