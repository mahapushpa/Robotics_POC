#define _TMR_C // used to control the global variable and function proto
/*******************************************************************************
* Filename    :- tmr.c
* Module      :- Timer component                               
*-------------------------------------------------------------------------------  
* Description :- Timer module to call refreshing and timer function.
*-------------------------------------------------------------------------------  
* Environment :- ARM STM32F205VE, no OS, compiled with KEIL RealView
*-------------------------------------------------------------------------------  
* Copyright   :- (c) 2013 MAPS Technologies, Jaipur         
 Author      :- Mahabir Prasad
*******************************************************************************/ 
/******************************************************************************/
/* Path where it is stored for configuration management                       */
/* $Header:  $                                                                */
/******************************************************************************/

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include  "tmr.h"
#include  "tmr_tab.h"
#include "lib.h"

/******************************************************************************/
/* Defines                                                                    */
/******************************************************************************/
#define TMR_STOPPED         0    /* count value for inactive (stopped) timers */

/******************************************************************************/
/* Internal Structures / Unions / param                                       */
/******************************************************************************/
typedef struct
{
  /* tick counter for mainloop timer */
  #ifdef TMR_USE_MODULE_MAINL
    ubyte ubModuleMlTickCount;
    #define tmr_ubModuleMlTickCount tmr_stVar.ubModuleMlTickCount
  #endif
    
  /* tick counter for ISR timer */
  #ifdef TMR_USE_MODULE_ISR
    ubyte ubModuleIsrTickCount;
    #define tmr_ubModuleIsrTickCount tmr_stVar.ubModuleIsrTickCount
  #endif
} tmr_tstVar;

static tmr_tstVar tmr_stVar;

const tmr_tstVar tmr_cstVar =
{
  /* tick counter for mainloop timer */
  #ifdef TMR_USE_MODULE_MAINL
    0xFF,
  #endif  
  /* tick counter for isr timer */
  #ifdef TMR_USE_MODULE_ISR
    0xFF
  #endif  
};

/* struct containing the counts for all timers */
static struct 
{
  /* Array containing the counts for all module timers on mainloop level */
  #ifdef TMR_USE_MODULE_MAINL
    uword  auwMainl[TMR_NUM_MODULE_MAINL];
  #endif

  #ifdef TMR_USE_MODULE_ISR
    uword aubIsr[TMR_NUM_MODULE_ISR];
  #endif
} tmr_staTimer;

/******************************************************************************/
/* Local Variables                                                            */
/******************************************************************************/

/******************************************************************************/
/* Internal Function prottypes                                                */
/******************************************************************************/

/******************************************************************************/
/* Global Functions                                                           */
/******************************************************************************/
/*******************************************************************************
* Function:- TMR_EXTERN void TMR_vStartModuleIsrTmr(ubyte ubTmrNum, ubyte ubCount)
*-------------------------------------------------------------------------------
* Description:- This function loads the counter of the given module timer on 
*               interrupt level with the passed count value. If the passed count
*               value is zero, the timer will be stopped (inactive), without 
*               prior execution of the accompanying module callback function.
*******************************************************************************/
#ifdef TMR_USE_MODULE_ISR 
TMR_EXTERN  void TMR_vStartModuleIsrTmr(ubyte ubTmrNum, uword ubCount)
{
  tmr_staTimer.aubIsr[ubTmrNum] = ubCount;
} /* TMR_vStartModuleIsrTmr */
#endif

/*******************************************************************************
* Function:- TMR_EXTERN void TMR_vStartModuleMainlTmr(ubyte ubTmrNum,uword uwCount)
*-------------------------------------------------------------------------------
* Description:- This function loads the counter of the given module timer on 
*               mainloop level with the passed count value. If the passed count 
*               value is zero, the timer will be stopped, and the accompanying
*               module callback function will not be executed.
*******************************************************************************/
#ifdef TMR_USE_MODULE_MAINL
TMR_EXTERN  void TMR_vStartModuleMainlTmr(ubyte ubTmrNum, uword uwCount)
{
  if (uwCount && (uwCount < 0xFF00) )  /* no overflow will occure with the */
  {                                    /* following  addition.             */
    uwCount = uwCount + 0xFF - tmr_ubModuleMlTickCount; 
                                  /* incr. the counter for the time that   */
                                  /*  happend till the last call of        */
                                  /*  TMR_vHandleStages.                   */
  }
  tmr_staTimer.auwMainl[ubTmrNum] = uwCount;  /*start timer */
} /* TMR_vStartModuleMainlTmr */
#endif

/*******************************************************************************
* Function:- TMR_EXTERN  void TMR_vHandleStages(void)
*-------------------------------------------------------------------------------
* Description:- This function checks all module mainloop timer on mainloop level
*               , weather they are expired or not. If a module timer is expired,
*               the accompanying module function is called and the timer is set
*               to TMR_STOPPED. The timer will also be set to TMR_STOPPED. 
*               It remains in this status, until it is started again.
*******************************************************************************/
TMR_EXTERN  void TMR_vHandleStages(void)
{
  ubyte ubTmrNum;                 /* number of current timer                */
  ubyte ubModuleMLTick;
  
	/* It is needed to control the call of function within 1 msec,           */
	/* Otherwise it keeps the same value, if It called faster than timer ISR */
	if(tmr_ubModuleMlTickCount == 0xFF)
	{
		return;
	}

  /* read tick counter setted from the interrupt routines and reset them,   */
  /* cause all ticks can be count while the execution of this function.     */

  #ifdef TMR_USE_MODULE_MAINL
    ubModuleMLTick = 0xFF - tmr_ubModuleMlTickCount; /*the counter decrem.  */
    tmr_ubModuleMlTickCount = 0xFF;                  /*from 0xFFFF.         */
  #endif
  
  /**************************************************************************
  * for all module timers on mainloop level
  **************************************************************************/
  #ifdef TMR_USE_MODULE_MAINL

  /* Two loops are used instead of one to be as fast as possible.     */
  /* Reason: irq is only enabled in the outer loop (every 16th timer) */
  /* In the inner loop the irq is only enabled, if a timer has been   */
  /* stopped and the callback function will be called.                */

  ubTmrNum = TMR_NUM_MODULE_MAINL;

  do
  {
    /* disable the interrupts while updating the timer array */
    /* to prevent malfunction while starting or stopping     */
    /* mainloop timer from interrupt-level                   */
    
    do
    {
      ubTmrNum--;
      /* is timer active ? */
      if (tmr_staTimer.auwMainl[ubTmrNum])
      {
        /* timer stopped in the last mainloop duration ? */
        if (tmr_staTimer.auwMainl[ubTmrNum] <= ubModuleMLTick)
        {
          /* stop timer and call the accompanying module function */
          tmr_staTimer.auwMainl[ubTmrNum] = TMR_STOPPED;

          /* call callbackfunction of the client  */
          tmr_apvModuleMainlTmrFunc[ubTmrNum]();
        }
        else
        {
          /* subtract the duration of the last mainloop from this timer*/
          tmr_staTimer.auwMainl[ubTmrNum] -= ubModuleMLTick;
        }  
      } 
    }
    while(ubTmrNum & 0x0F);      /* leave inner loop every 16th time */
  }
  while(ubTmrNum);
  #endif /*TMR_USE_MODULE_MAINL*/
} /* TMR_vHandleStages */

/*******************************************************************************
* Function :- static  void tmr_vTMR0IrqHandler(void) __irq 
*-------------------------------------------------------------------------------
* Description :- If a module timer on interrupt level is expired, the
*                accompanying module function is called and the timer
*                remains stopped (inactive), until it is started again.
*                The prescaler and tick count for the module mainloop 
*                timers.
*******************************************************************************/
TMR_EXTERN  void TMR_vServiceISR(void)
{
	ubyte ubTmrNum;                 /* number of current timer  */

		/**************************************************************************
		* module timers on interrupt level
		**************************************************************************/
		#ifdef TMR_USE_MODULE_ISR
		  ubTmrNum = TMR_NUM_MODULE_ISR - 1;
		  do
		  {
		    if (tmr_staTimer.aubIsr[ubTmrNum])   /* is timer active ? */
		    {
		      /*`then decrement it, is timer now expired ? */
		      if (--tmr_staTimer.aubIsr[ubTmrNum] == TMR_STOPPED)
		      {
		        /* then execute the accompanying module function */
		        tmr_apvModuleIsrTmrFunc[ubTmrNum]();
		      }
		    }
		  }
		  while (ubTmrNum--);
		#endif /*TMR_USE_MODULE_ISR*/ 
		
		/**************************************************************************
		* decrement module timer prescaler and tick count
		**************************************************************************/
		#ifdef TMR_USE_MODULE_MAINL
		   tmr_ubModuleMlTickCount--;   /* decrement tick counter  */
		#endif /* TMR_USE_MODULE_MAINL */
	}	// end of 1 msec count

/*******************************************************************************
* Function:- TMR_EXTERN  void  TMR_vStart(void)
*-------------------------------------------------------------------------------
* Description:- This function does all necessary initialization of the timer 
*               module and installs the hardware timer sources for the mainloop.
*******************************************************************************/
TMR_EXTERN  void  TMR_vStart(void)
{
  /****************************************************************************/
  /* set all count values to 'inactive' ...                                   */
  /****************************************************************************/
  /* for all timers set default value 0 (= TMR_STOPPED ) */
  LIB_vMemClear(&tmr_staTimer, sizeof(tmr_staTimer));

  /*  Copy stage divider limits to stage counters */
  LIB_vMemCopy(&tmr_stVar, &tmr_cstVar, sizeof(tmr_stVar));

  /****************************************************************************/
  /* Here begins the hardware initialization                                  */
  /****************************************************************************/
  /*==========================================================================*/
  // Timer initialisation with SYS_CLK 24Mhz -> Resolution = 1.0 ms
  /*--------------------------------------------------------------------------*/
	/* SystemFrequency / 1000    1ms
	 * SystemFrequency / 100000  10us
	 * SystemFrequency / 1000000 1us
	 */
  //(void)SysTick_Config(SystemCoreClock/1000);	 // start for 1 msec
} /* TMR_vStart */

#undef   _TMR_C                                                     /* _TMR_C */
/******************************************************************************/
/* Changes in version                                                         */
/* $Log:  $                                                                   */
/******************************************************************************/
/* End of Source File                                                         */
/******************************************************************************/

